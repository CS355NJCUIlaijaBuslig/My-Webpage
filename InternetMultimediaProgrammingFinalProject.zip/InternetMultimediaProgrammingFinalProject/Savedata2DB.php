<html>
   <head>
      <title>Publication Form</title>
   </head>
   <body background="AndroidBackground.jpg">
   <h1>Publication Form</h1>
      <form method='post' action='Savedata2DB.php'><pre>
           Author: <input type='text'     name='author'     />
            Title: <input type='text'     name='title'    />
         category: <input type='text'     name='category' />
         year: <input type='text' name='year' />
         isbn: <input type='text' name='isbn' />          
				   <input type='submit' value='Submit details' />
      </pre></form>
   </body>
</html>

<a href="IlaijaBusligWebpage.html">Back to Ilaija's Homepage</a>
<a href="processform.php">Process Form</a>

<?php // Savedata2DB.php

require_once 'login1.php';



if (isset($_POST['author']))
{
   $author = $_POST['author'];
   $title = $_POST['title'];
   $category = $_POST['category'];
   $year = $_POST['year'];
   $isbn = $_POST['isbn'];

   echo "The data you entered was:<ul>" .
        "author = $author<br />" .
        "title = $title<br />" .
        "category = $category<br />" .
        "year = $year<br />" .
		"isbn = $isbn</ul>";


  $query1 = "INSERT INTO classics VALUES('$author', '$title', '$category', '$year', '$isbn')";

echo $query1;

   $result1 = mysqli_query($link,$query1);
echo $result1;
}



?>
