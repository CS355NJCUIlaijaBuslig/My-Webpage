<?php // connectioin to Database -

$db_hostname = 'localhost';
$db_database = 'publications';
$db_username = 'root';
$db_password = '';

$link = mysqli_connect($db_hostname, $db_username, $db_password);
if (!$link) {
    die('Cannot connect to MySQL: ' . mysqli_error($link));
}
else {
echo 'Connected OK!';
}
 
// create database to use

$sql = "CREATE DATABASE publications";
if (mysqli_query($link,$sql)) {
    echo "Database publications created successfully\n";
} else {
    echo 'Error creating database: ' . mysqli_error($link) . "\n";
}

// select database to use

$db_selected = mysqli_select_db($link,$db_database);

if (!$db_selected) {
 die('Cannot select database: ' . mysqli_error($link));
}
echo 'database selected';

$query =


"CREATE TABLE if not exists classics (" .
 "author VARCHAR(128)," .
 "title VARCHAR(128)," .
 "category VARCHAR(16)," .
 "year SMALLINT(6)," .
 "isbn CHAR(13)," .
 "INDEX(author(20)), ".
 "INDEX(title(20)), ".
 "INDEX(category(4))," .
 "INDEX(year)," .
 "PRIMARY KEY (isbn)) ENGINE MyISAM;"; 

echo $query;

$result = mysqli_query($link,$query);
echo $result;

if ($result) echo 'Table now created (or already exists).<br />';

?>
