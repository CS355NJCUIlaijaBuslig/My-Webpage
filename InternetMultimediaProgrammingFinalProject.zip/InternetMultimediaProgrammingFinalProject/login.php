<?php // connectioin to Database -

$db_hostname = 'localhost';
$db_database = 'webuser';
$db_username = 'root';
$db_password = '';

$link = mysql_connect($db_hostname, $db_username, $db_password);
if (!$link) {
    die('Cannot connect to MySQL: ' . mysql_error());
}
else {
echo 'Connected OK!';
}
 
// create database to use

$sql = "CREATE DATABASE $db_database";
if (mysql_query($sql)) {
    echo "Database $db_database created successfully\n";
} else {
    echo 'Error creating database: ' . mysql_error() . "\n";
}

// select database to use

$db_selected = mysql_select_db($db_database,$link);

if (!$db_selected) {
 die('Cannot select database: ' . mysql_error());
}
echo 'database selected';

$query =
   "CREATE TABLE IF NOT EXISTS users(\n" .
   "   name VARCHAR(16),\n" .
   "   email CHAR(32),\n"    .
   "   username VARCHAR(32),\n" .
   "   password VARCHAR(32))";

echo $query;

$result = mysql_query($query);
echo $result;

if ($result) echo 'Table now created (or already exists).<br />';

?>
