<html>
   <head>
      <title>Form Processing</title>
   </head>
   <body>
      <form method='post' action='Savedata2DB.php'><pre>
             Author: <input type='text'     name='author'     />
              Title: <input type='text'     name='title'    />
           Category: <input type='text'     name='category' />
			   Year: <input type='text'		name='Year' />	
               ISBN: <input type='text'     name='isbn' />
                     <input type='submit' value='Submit details' />
      </pre></form>
   </body>
</html>

<?php // Savedata2DB.php

require_once 'login.php';



if (isset($_POST['name']))
{
   $author   = $_POST['author'];
   $title    = $_POST['title'];
   $category = $_POST['category'];
   $year = $_POST['year'];
   $isbn = $_POST['isbn'];

   echo "The data you entered was:<ul>" .
        "Author = $author<br />" .
        "Title = $title<br />" .
        "Category = $category<br />" .
		"Year = $year<br />" .
        "ISBN = $isbn</ul>"


  $query1 = "INSERT INTO users VALUES('$author', '$title', '$category', '$year', '$isbn')";

echo $query1;

   $result1 = mysql_query($query1);
echo $result1;
}

if ($result1) echo 'Users now added to DB.<br />';

?>
